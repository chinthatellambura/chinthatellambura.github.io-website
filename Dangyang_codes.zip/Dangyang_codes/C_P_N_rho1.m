%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Channel capacity
% 
%Feb.14th.2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
clc;
tic
block_L = 1e4;                      
P0_dB =0:2:20;
P0 = 10.^(P0_dB/10);
T = 1;
tau = 0.6;
eta = 0.9;
rho = 0.6;
N0 = 1;
Capacity_simulation1 = zeros(1,length(P0_dB));
Capacity_integeral1 = zeros(1,length(P0_dB));   % scheme1����
Capacity_asymptotic1 = zeros(1,length(P0_dB));

Capacity_simulation2 = zeros(1,length(P0_dB));
Capacity_integeral2 = zeros(1,length(P0_dB));   % scheme1����
Capacity_asymptotic2 = zeros(1,length(P0_dB));

Capacity_simulation3 = zeros(1,length(P0_dB));
Capacity_integeral3 = zeros(1,length(P0_dB));   % scheme1����
Capacity_asymptotic3 = zeros(1,length(P0_dB));

Capacity_simulation4 = zeros(1,length(P0_dB));
Capacity_integeral4 = zeros(1,length(P0_dB));   % scheme1����
Capacity_asymptotic4 = zeros(1,length(P0_dB));
%%%%%%%%%%%%%
% 1
%%%%%%%%%%%%%
N = 1;
for i = 1 : length(P0_dB)
%% simulation
    Delta = tau .* eta .* P0(i) ./ ((1-tau) * N0);
    for j = 1 : block_L
         h_D = sqrt(1 / 2) * (normrnd(0, 1, 1, N) + 1j * normrnd(0, 1, 1, N));
         g_U = sqrt(1 / 2) * (normrnd(0, 1, 1, N) + 1j * normrnd(0, 1, 1, N));
         n = sqrt(1 / 2) * (normrnd(0, 1, 1, N) + 1j * normrnd(0, 1, 1, N));
         h_hat = rho * h_D + sqrt(1 - rho^2) * n;
         g_hat = rho * g_U + sqrt(1 - rho^2) * n;
         X = (abs(h_D * h_hat')) ^2 / (h_hat * h_hat');
         Y = (abs(g_U * g_hat')) ^2 / (g_hat * g_hat');
         cap(i, j) = log2(1+Delta * X * Y);
    end 
    SUM(i) = mean(cap(i,:));
    Capacity_simulation1(i) = (1-tau)* SUM(i);
    
%% integeral
I = 0;
for n = 1 : N
    for m = 1 : N
        An = factorial(N-1)/(factorial(N-n)*factorial(n-1)) * (1 - rho^2)^(N - n) * rho^(2*(n-1));
        Am = factorial(N-1)/(factorial(N-m)*factorial(m-1)) * (1 - rho^2)^(N - m) * rho^(2*(m-1));
        alpha = (n + m -2) / 2;
        beta = n - m;
        c = 2 * An * Am / (log(2) * gamma(n) * gamma(m) * Delta^(alpha+1));
        fun = @(z) log(1+z) .* z.^alpha .* besselk(beta,2*sqrt(z/Delta));
        q = integral(fun,0,inf);
        I = c * q + I;
    end
end
Capacity_integeral1(i) = (1-tau) * I;


%% asymptotic
I1 = 0;
for n = 1 : N
    for m = 1 : N
        An = factorial(N-1)/(factorial(N-n)*factorial(n-1)) * (1 - rho^2)^(N - n) * rho^(2*(n-1));
        Am = factorial(N-1)/(factorial(N-m)*factorial(m-1)) * (1 - rho^2)^(N - m) * rho^(2*(m-1));
        alpha = (n + m -2) / 2;
        beta = n - m;
        Phi = gamma(alpha + 1 + beta/2) * gamma(alpha + 1 - beta/2);
        c = An * Am * Phi / (gamma(n) * gamma(m) * log(2));
        Xi = psi(alpha+1+beta/2) + psi(alpha+1-beta/2);
        I1 = c * (Xi + log(eta*P0(i)/N0)-log((1-tau)/(tau)))+I1;
    end
end
Capacity_asymptotic1(i) = (1-tau) * I1;
end
%%%%%%%%%
%2
%%%%%%%%
N = 2;
for i = 1 : length(P0_dB)
%% simulation
    Delta = tau .* eta .* P0(i) ./ ((1-tau) * N0);
    for j = 1 : block_L
         h_D = sqrt(1 / 2) * (normrnd(0, 1, 1, N) + 1j * normrnd(0, 1, 1, N));
         g_U = sqrt(1 / 2) * (normrnd(0, 1, 1, N) + 1j * normrnd(0, 1, 1, N));
         n = sqrt(1 / 2) * (normrnd(0, 1, 1, N) + 1j * normrnd(0, 1, 1, N));
         h_hat = rho * h_D + sqrt(1 - rho^2) * n;
         g_hat = rho * g_U + sqrt(1 - rho^2) * n;
         X = (abs(h_D * h_hat')) ^2 / (h_hat * h_hat');
         Y = (abs(g_U * g_hat')) ^2 / (g_hat * g_hat');
         cap(i, j) = log2(1+Delta * X * Y);
    end 
    SUM(i) = mean(cap(i,:));
    Capacity_simulation2(i) = (1-tau)* SUM(i);
    
%% integeral
I = 0;
for n = 1 : N
    for m = 1 : N
        An = factorial(N-1)/(factorial(N-n)*factorial(n-1)) * (1 - rho^2)^(N - n) * rho^(2*(n-1));
        Am = factorial(N-1)/(factorial(N-m)*factorial(m-1)) * (1 - rho^2)^(N - m) * rho^(2*(m-1));
        alpha = (n + m -2) / 2;
        beta = n - m;
        c = 2 * An * Am / (log(2) * gamma(n) * gamma(m) * Delta^(alpha+1));
        fun = @(z) log(1+z) .* z.^alpha .* besselk(beta,2*sqrt(z/Delta));
        q = integral(fun,0,inf);
        I = c * q + I;
    end
end
Capacity_integeral2(i) = (1-tau) * I;


%% asymptotic
I1 = 0;
for n = 1 : N
    for m = 1 : N
        An = factorial(N-1)/(factorial(N-n)*factorial(n-1)) * (1 - rho^2)^(N - n) * rho^(2*(n-1));
        Am = factorial(N-1)/(factorial(N-m)*factorial(m-1)) * (1 - rho^2)^(N - m) * rho^(2*(m-1));
        alpha = (n + m -2) / 2;
        beta = n - m;
        Phi = gamma(alpha + 1 + beta/2) * gamma(alpha + 1 - beta/2);
        c = An * Am * Phi / (gamma(n) * gamma(m) * log(2));
        Xi = psi(alpha+1+beta/2) + psi(alpha+1-beta/2);
        I1 = c * (Xi + log(eta*P0(i)/N0)-log((1-tau)/(tau)))+I1;
    end
end
Capacity_asymptotic2(i) = (1-tau) * I1;
end
%%%%%%%%%%%%%
%3
%%%%%%%%%%%%%
N = 3;
for i = 1 : length(P0_dB)
%% simulation
    Delta = tau .* eta .* P0(i) ./ ((1-tau) * N0);
    for j = 1 : block_L
         h_D = sqrt(1 / 2) * (normrnd(0, 1, 1, N) + 1j * normrnd(0, 1, 1, N));
         g_U = sqrt(1 / 2) * (normrnd(0, 1, 1, N) + 1j * normrnd(0, 1, 1, N));
         n = sqrt(1 / 2) * (normrnd(0, 1, 1, N) + 1j * normrnd(0, 1, 1, N));
         h_hat = rho * h_D + sqrt(1 - rho^2) * n;
         g_hat = rho * g_U + sqrt(1 - rho^2) * n;
         X = (abs(h_D * h_hat')) ^2 / (h_hat * h_hat');
         Y = (abs(g_U * g_hat')) ^2 / (g_hat * g_hat');
         cap(i, j) = log2(1+Delta * X * Y);
    end 
    SUM(i) = mean(cap(i,:));
    Capacity_simulation3(i) = (1-tau)* SUM(i);
    
%% integeral
I = 0;
for n = 1 : N
    for m = 1 : N
        An = factorial(N-1)/(factorial(N-n)*factorial(n-1)) * (1 - rho^2)^(N - n) * rho^(2*(n-1));
        Am = factorial(N-1)/(factorial(N-m)*factorial(m-1)) * (1 - rho^2)^(N - m) * rho^(2*(m-1));
        alpha = (n + m -2) / 2;
        beta = n - m;
        c = 2 * An * Am / (log(2) * gamma(n) * gamma(m) * Delta^(alpha+1));
        fun = @(z) log(1+z) .* z.^alpha .* besselk(beta,2*sqrt(z/Delta));
        q = integral(fun,0,inf);
        I = c * q + I;
    end
end
Capacity_integeral3(i) = (1-tau) * I;

%% asymptotic
I1 = 0;
for n = 1 : N
    for m = 1 : N
        An = factorial(N-1)/(factorial(N-n)*factorial(n-1)) * (1 - rho^2)^(N - n) * rho^(2*(n-1));
        Am = factorial(N-1)/(factorial(N-m)*factorial(m-1)) * (1 - rho^2)^(N - m) * rho^(2*(m-1));
        alpha = (n + m -2) / 2;
        beta = n - m;
        Phi = gamma(alpha + 1 + beta/2) * gamma(alpha + 1 - beta/2);
        c = An * Am * Phi / (gamma(n) * gamma(m) * log(2));
        Xi = psi(alpha+1+beta/2) + psi(alpha+1-beta/2);
        I1 = c * (Xi + log(eta*P0(i)/N0)-log((1-tau)/(tau)))+I1;
    end
end
Capacity_asymptotic3(i) = (1-tau) * I1;
end

%%%%%%%%%%%%%
%4
%%%%%%%%%%%%%
N = 4;
for i = 1 : length(P0_dB)
%% simulation
    Delta = tau .* eta .* P0(i) ./ ((1-tau) * N0);
    for j = 1 : block_L
         h_D = sqrt(1 / 2) * (normrnd(0, 1, 1, N) + 1j * normrnd(0, 1, 1, N));
         g_U = sqrt(1 / 2) * (normrnd(0, 1, 1, N) + 1j * normrnd(0, 1, 1, N));
         n = sqrt(1 / 2) * (normrnd(0, 1, 1, N) + 1j * normrnd(0, 1, 1, N));
         h_hat = rho * h_D + sqrt(1 - rho^2) * n;
         g_hat = rho * g_U + sqrt(1 - rho^2) * n;
         X = (abs(h_D * h_hat')) ^2 / (h_hat * h_hat');
         Y = (abs(g_U * g_hat')) ^2 / (g_hat * g_hat');
         cap(i, j) = log2(1+Delta * X * Y);
    end 
    SUM(i) = mean(cap(i,:));
    Capacity_simulation4(i) = (1-tau)* SUM(i);
    
%% integeral
I = 0;
for n = 1 : N
    for m = 1 : N
        An = factorial(N-1)/(factorial(N-n)*factorial(n-1)) * (1 - rho^2)^(N - n) * rho^(2*(n-1));
        Am = factorial(N-1)/(factorial(N-m)*factorial(m-1)) * (1 - rho^2)^(N - m) * rho^(2*(m-1));
        alpha = (n + m -2) / 2;
        beta = n - m;
        c = 2 * An * Am / (log(2) * gamma(n) * gamma(m) * Delta^(alpha+1));
        fun = @(z) log(1+z) .* z.^alpha .* besselk(beta,2*sqrt(z/Delta));
        q = integral(fun,0,inf);
        I = c * q + I;
    end
end
Capacity_integeral4(i) = (1-tau) * I;

%% asymptotic
I1 = 0;
for n = 1 : N
    for m = 1 : N
        An = factorial(N-1)/(factorial(N-n)*factorial(n-1)) * (1 - rho^2)^(N - n) * rho^(2*(n-1));
        Am = factorial(N-1)/(factorial(N-m)*factorial(m-1)) * (1 - rho^2)^(N - m) * rho^(2*(m-1));
        alpha = (n + m -2) / 2;
        beta = n - m;
        Phi = gamma(alpha + 1 + beta/2) * gamma(alpha + 1 - beta/2);
        c = An * Am * Phi / (gamma(n) * gamma(m) * log(2));
        Xi = psi(alpha+1+beta/2) + psi(alpha+1-beta/2);
        I1 = c * (Xi + log(eta*P0(i)/N0)-log((1-tau)/(tau)))+I1;
    end
end
Capacity_asymptotic4(i) = (1-tau) * I1;
end
%% plot
figure1 = figure;
plot(P0_dB, Capacity_simulation1(1,:),'r^');
hold on;
grid on;
plot(P0_dB, Capacity_integeral1(1,:),'b');
plot(P0_dB, Capacity_asymptotic1(1,:),'r:');
legend('Simulation','Analysis','Asymptotic');
set(legend,'Interpreter','latex','location','SouthEast','FontSize',12);
plot(P0_dB, Capacity_simulation2(1,:),'g^');
plot(P0_dB, Capacity_simulation3(1,:),'y^');
plot(P0_dB, Capacity_simulation4(1,:),'b^');
plot(P0_dB, Capacity_integeral2(1,:),'b');
plot(P0_dB, Capacity_asymptotic2(1,:),'g-');
plot(P0_dB, Capacity_integeral3(1,:),'b');
plot(P0_dB, Capacity_asymptotic3(1,:),'y-');
plot(P0_dB, Capacity_integeral4(1,:),'b');
plot(P0_dB, Capacity_asymptotic4(1,:),'b-');
xlabel('$P$(dBm)','Interpreter','latex','FontSize',12);
ylabel('$C$','Interpreter','latex','FontSize',12);
%Create textarrow
annotation(figure1,'textarrow',[0.409586056644881 0.156862745098039],...
    [0.512784461152881 0.776942355889724],'TextEdgeColor','none',...
    'FontSize',12,'TextBackgroundColor',[1 1 1],...
    'Interpreter','latex',...
    'String',{'$N = 1,2,3,4$'});
toc