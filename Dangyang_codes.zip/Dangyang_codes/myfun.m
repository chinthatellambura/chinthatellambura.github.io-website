 function y = myfun(x,m,j)
        y = besselk((2*j-m),x);