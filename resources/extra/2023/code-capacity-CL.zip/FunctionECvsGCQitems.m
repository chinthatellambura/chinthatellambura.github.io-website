 function [Isn,Ix,Ix_GCQ,Isy,Isy_GCQ]=...
    FunctionECvsGCQitems(PsdB,sigmaW,eta,tau,EE,Q_GCQ,Period_X,sigma_sr0,sigma_st0,sigma_tr0,dist_sr,dist_st,dist_tr,alpha)
sigma_sr=sigma_sr0/dist_sr^alpha;
sigma_st=sigma_st0/dist_st^alpha;
sigma_tr=sigma_tr0/dist_tr^alpha;

PsW=db2pow(PsdB);
L0=tau/EE/(1-eta)/PsW;
snr_bar=PsW./sigmaW;


Prob_no=1-exp(-L0/sigma_st); %No reflection
%%
c0=1/sigma_sr/snr_bar;
Isn=-Prob_no*exp(c0)*ei(-c0)/log(2);
%%%%%%%%I2  =I_x
Q2=Q_GCQ;
wi2=pi/Q2;
q2=1:Q2;
xi2=cos((2*q2-1)/2/Q2*pi);
zi2=2*L0./(xi2+1);
I_LB=1./snr_bar/Period_X./eta./sigma_tr./zi2;

MI2=-ei(-I_LB);
Ix_GCQ=1/sigma_st/L0/2/log(2)*wi2*sum((exp(-zi2/sigma_st+I_LB).*MI2.*zi2.^2.*sqrt(1-xi2.^2)))/Period_X; 

fun2=@(x,y) exp(-x/sigma_st)/sigma_st.*exp(-y/sigma_tr)/sigma_tr.*log2(1+Period_X*snr_bar.*eta.*x.*y)/Period_X; 
Ix=integral2(fun2,L0,Inf,0,Inf);
%%    
%%%%%%%%%%%% I_{s,y}
Q3=Q_GCQ;
wi3=pi/Q3;
q3=1:Q3;
L1=sigma_sr+eta*sigma_tr*L0;
xi3=cos((2*q3-1)/2/Q3*pi);
zi3=2*L1./(xi3+1);
I_LB3=1./snr_bar./zi3;
front=1./log(2)/eta/sigma_st/sigma_tr.*exp(sigma_sr/eta/sigma_st/sigma_tr)./2./L1.*wi3;

MI3=-ei(-I_LB3);
back=(exp(-zi3/eta/sigma_st/sigma_tr+I_LB3).*MI3.*zi3.^2.*sqrt(1-xi3.^2));      
Isy_GCQ=front*sum(back);  

T0=1/(eta*sigma_st*sigma_tr);
front=T0./log(2)*exp(sigma_sr*T0);
fun3=@(y) -exp(-T0.*y+1/snr_bar./y).*ei(-1/snr_bar./y); 
back=integral(fun3,L1,Inf);
Isy=front*back;