 function [Ec_WO,Ec_WO_GCQ,Ec_DR,Ec_BR, Ec,Ec_GCQ,Ec_lowSNR,Ec_highSNR,Ec_UB]=...
    FunctionErgodicCapacitySensitivity4(PsdB,sigmaW,eta,tau,EE,X_GCQ,S_GCQ,Period_X,sigma_sr0,sigma_st0,sigma_tr0,dist_sr,dist_st,dist_tr,alpha)

sigma_sr=sigma_sr0/dist_sr^alpha;
sigma_st=sigma_st0/dist_st^alpha;
sigma_tr=sigma_tr0/dist_tr^alpha;

PsW=db2pow(PsdB);
L0=tau/EE/(1-eta)/PsW;
snr_bar=PsW./sigmaW;

Prob_no=1-exp(-L0/sigma_st); %No reflection
%%
%%%%%%%%I0=I^hat_{s,n}
c0=1/sigma_sr/snr_bar;
I0=-exp(c0)*ei(-c0)/log(2);

Ec_DR=I0;
%%%%%%%%I2  =I_x
q2=1:X_GCQ;
ti2=cos((2*q2-1)/2/X_GCQ*pi);
xi2=2*L0./(ti2+1);
I_LB=1./(Period_X.*snr_bar.*eta.*sigma_tr.*xi2);

% I2_CGQ=0;
% for Times2=1:X_GCQ
% %     MI2=-ei(-I_LB(Times2)); %=integral(@(x2) exp(-x2).*x2.^(-1),I_LB(Times2),Inf); %Gamma(0,I_LB)
%     MI2=integral(@(x2) exp(-x2).*x2.^(-1),I_LB(Times2),Inf); %Gamma(0,I_LB)
%     I2_CGQ=I2_CGQ+pi/X_GCQ/sigma_st/L0/2/log(2)*(exp(-xi2(Times2)/sigma_st+I_LB(Times2)).*MI2.*xi2(Times2).^2.*sqrt(1-ti2(Times2).^2)); 
% end
%I2_CGQ
MI2=-ei(-I_LB);
%sum_e0=exp(-xi2/sigma_st+I_LB).*MI2.*xi2.^2.*sqrt(1-ti2.^2);
% a=exp(I_LB/7).*MI2
% b=exp(I_LB/7).*MI2.*exp(I_LB/7).*exp(I_LB/7)%.*exp(I_LB/6)
sum_e=exp(I_LB/7).*MI2.*exp(I_LB/7).*exp(I_LB/7).*xi2.^2.*exp(I_LB/7).*exp(I_LB/7).*sqrt(1-ti2.^2).*exp(I_LB/7).*exp(-xi2/sigma_st).*exp(I_LB/7);


Ix_CGQ=pi/(2*log(2)*X_GCQ*Period_X*L0*sigma_st)*sum(sum_e);

fun2=@(x,y) exp(-x/sigma_st)/sigma_st.*exp(-y/sigma_tr)/sigma_tr.*log2(1+Period_X*snr_bar.*eta.*x.*y)/Period_X; 
Ix=integral2(fun2,L0,Inf,0,Inf);
Ec_BR=Ix;    %传统反向散射，非协作，只解码反射信号
%%    
%%%%%%%%%%%% I_{s,y}
tStart_1 = tic;
wi3=pi/S_GCQ;
q3=1:S_GCQ;
L1=sigma_sr+eta*sigma_tr*L0;
T0=1/(eta*sigma_st*sigma_tr);
zi3=cos((2*q3-1)/2/S_GCQ*pi);
si3=2*L1./(zi3+1);
I_LB3=1./snr_bar./si3;
front=T0./log(2).*exp(sigma_sr*T0)./2./L1.*wi3;

% I3_CGQ=0;
% for Times3=1:Q3
%     MI3=integral(@(x3) exp(-x3).*x3.^(-1),I_LB3(Times3),Inf);
%     back=(exp(-si3(Times3)*T0+I_LB3(Times3)).*MI3.*si3(Times3).^2.*sqrt(1-zi3(Times3).^2));      
%     I3_CGQ=I3_CGQ+front*back;  
% end

MI3=-ei(-I_LB3);
back=(exp(-si3*T0+I_LB3).*MI3.*si3.^2.*sqrt(1-zi3.^2));      
Isy_CGQ=front*sum(back); 
costTime_1 = toc(tStart_1)
%%%%%%%%%%%以下两种计算方式都正确
%%%%%%%%%%%%方式1
% front=1./log(2)/eta/sigma_st/sigma_tr;
% fun3=@(y,x) exp(-(y-sigma_sr)*T0+1/snr_bar./y).*exp(-x)./x; 
% xmin=@(y) 1./snr_bar./y;
% back=integral2(fun3,L1,Inf,xmin,Inf);
% I3=front*back;
%%%%%%%%%%%%方式2
front=T0./log(2)*exp(sigma_sr*T0);
fun3=@(y) -exp(-T0.*y+1/snr_bar./y).*ei(-1/snr_bar./y); 
back=integral(fun3,L1,Inf);
Isy=front*back;
%% 
%%%%%%%%I0 at Lower SNR I0_0   %%%%%%仿真表明这种性能更好
    esn=sigma_sr;
    esn2=2*sigma_sr^2;
    Isn_lowSNR=snr_bar*esn/(1+esn2/esn/2*snr_bar)/log(2);
    Isn_UB=log2(1+snr_bar*esn);
%    I0_lowSNR=1/(1+c0)/log(2);%c0=snr_bar*sigma_sr;
%%%%%%%%I11 at Lower SNR I11_0

    esy=sigma_sr*exp(-L0/sigma_st)+1/T0*gammainc(L0/sigma_st,2,'upper')*gamma(2);
 %   T0=1/(eta*sigma_st*sigma_tr);
    esy2=2/T0^2*exp(sigma_sr*T0)*gammainc(sigma_sr*T0+L0/sigma_st,3,'upper')*gamma(3);
  
    Isy_lowSNR=snr_bar*esy/(1+esy2/esy/2*snr_bar)/log(2);
     Isy_UB=log2(1+snr_bar*esy);
%%%%%%%%I2 at Lower SNR I2_0
    ex=eta*sigma_st*sigma_tr*gammainc(L0/sigma_st,2,'upper')*gamma(2);
    ex2=2*eta^2*sigma_st^2*sigma_tr^2*gammainc(L0/sigma_st,3,'upper')*gamma(3); %exp(-L0/sigma_st)
    Ix_lowSNR=snr_bar*ex/(1+ex2/ex/2*snr_bar*Period_X)/log(2);
    Ix_UB=log2(1+snr_bar*ex*Period_X)/Period_X;
% %%
%% 
%%%%%%%%I0 at Lower SNR I0_0
%     Isn_lowSNR=snr_bar*sigma_sr/log(2);
%     Isn_UB=log2(1+snr_bar*sigma_sr);
%     I0_lowSNR=1/(1+c0)/log(2);%c0=snr_bar*sigma_sr;
% %%%%%%%I11 at Lower SNR I11_0
% 
%     esy=sigma_sr*exp(-L0/sigma_st)+eta*sigma_st*sigma_tr*gammainc(L0/sigma_st,2,'upper')*gamma(2);
%     Isy_lowSNR=esy*snr_bar/log(2);
%      Isy_UB=log2(1+snr_bar*esy);
% %%%%%%%I2 at Lower SNR I2_0
%     ex=eta*sigma_st*sigma_tr*gammainc(L0/sigma_st,2,'upper')*gamma(2);
%     Ix_lowSNR=snr_bar*ex/log(2);
%     Ix_UB=log2(1+snr_bar*ex*K)/K;
% %% 
%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%High SNR
%%%%%%%%I0 at High SNR I0_infnity
    Isn_highSNR=log2(snr_bar*sigma_sr)-eulergamma/log(2); %eulergamma=0.5772;
    %    I0_highSNR=-log2(c0)-eulergamma/log(2); %eulergamma=0.5772;
%%%%%%%%I11 at High SNR I11_infnity
    ratio=sigma_sr/(eta*sigma_st*sigma_tr);
%    Isy_highSNR=(log2(snr_bar*L1)-eulergamma/log(2))*exp(-L0/sigma_st)-exp(ratio)*integral(@(x) exp(x)./x,-Inf,-ratio*L1/sigma_sr)/log(2);
   Isy_highSNR=(log2(snr_bar*L1)-eulergamma/log(2))*exp(-L0/sigma_st)-exp(ratio)*ei(-L1*ratio/sigma_sr)/log(2);
    %%%%%%%%I2 at High SNR I2_infnity
%    Ix_highSNR=(log2(snr_bar*eta*sigma_tr*L0)-eulergamma/log(2))*exp(-L0/sigma_st)-integral(@(x) exp(x)./x,-Inf,-L0/sigma_st)/log(2);
    Ix_highSNR=(log2(Period_X*snr_bar*eta*sigma_tr*L0)-eulergamma/log(2))*exp(-L0/sigma_st)-ei(-L0/sigma_st)/log(2);
    Ix_highSNR=Ix_highSNR/Period_X;
    %%

%1-exp(-A/sigma_st)+2*exp(-A/sigma_st)*exp(-A/sigma_st)
    Ec=Prob_no*I0+(Ix+Isy);
    Ec_UB=Prob_no*Isn_UB+(Ix_UB+Isy_UB);
    Ec_GCQ=Prob_no*I0+(Ix_CGQ+Isy_CGQ);
    Ec_lowSNR=Prob_no*Isn_lowSNR+(Ix_lowSNR+Isy_lowSNR);
    Ec_highSNR=Prob_no*Isn_highSNR+(Ix_highSNR+Isy_highSNR); 
    
funWO2=@(x,y) exp(-x/sigma_st)/sigma_st.*exp(-y/sigma_tr)/sigma_tr.*log2(1+Period_X*snr_bar.*eta.*x.*y)/Period_X; 
IWO2=integral2(funWO2,0,Inf,0,Inf);
% funWO3=@(y,x) 1./sigma_st.*exp(-y./sigma_st+1/snr_bar./(sigma_sr+eta*sigma_tr.*y)).*exp(-x)./x; 
% xminWO=@(y) 1./snr_bar./(sigma_sr+eta*sigma_tr.*y);
% I3WO=integral2(funWO3,0,Inf,xminWO,Inf)./log(2);
funWO3=@(y) -exp(-T0.*y+1/snr_bar./y).*ei(-1/snr_bar./y); 
I3WO=front*integral(funWO3,sigma_sr,Inf);
Ec_WO=(IWO2+I3WO);

%%%%%%%%%%%% I_{x} sensitivity tends to -infinity, always-on backscatter
q22=1:X_GCQ;
ti22=cos((2*q22-1)/2/X_GCQ*pi);
yi22=pi/4.*(ti22+1);
xi22=tan(yi22);
I_LB2=1./(Period_X.*snr_bar.*eta.*sigma_tr.*xi22);
MI22=-ei(-I_LB2);
sum_e2=exp(I_LB2/7).*MI22.*exp(I_LB2/7).*exp(I_LB2/7)./cos(yi22).^2.*exp(I_LB2/7).*exp(I_LB2/7).*sqrt(1-ti22.^2).*exp(I_LB2/7).*exp(-xi22/sigma_st).*exp(I_LB2/7);

Ix_GCQ2=pi^2/(4*log(2)*X_GCQ*Period_X*sigma_st)*sum(sum_e2);

%%%%%%%%%%%% I_{s,y} sensitivity tends to -infinity, always-on backscatter
wi32=pi/S_GCQ;
q32=1:S_GCQ;
L12=sigma_sr;
T02=1/(eta*sigma_st*sigma_tr);
zi32=cos((2*q32-1)/2/S_GCQ*pi);
si32=2*L12./(zi32+1);
I_LB32=1./snr_bar./si32;
front2=T02./log(2).*exp(sigma_sr*T02)./2./L12.*wi32;

MI32=-ei(-I_LB32);
back2=(exp(-si32*T02+I_LB32).*MI32.*si32.^2.*sqrt(1-zi32.^2));      
Isy_GCQ2=front2*sum(back2);  
Ec_WO_GCQ=Ix_GCQ2+Isy_GCQ2;