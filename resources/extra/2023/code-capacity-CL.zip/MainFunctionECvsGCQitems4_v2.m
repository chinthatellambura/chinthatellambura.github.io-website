clear; clc; %%%%%用这个仿真结果
sigma_sr0=1; sigma_st0=1; sigma_tr0=1;

alpha=2;     %path loss
alphaL=3;   %path loss
dist_sr=1;  %m
dist_st=1;  %m
dist_tr=1;  %m

eta=0.3; %反射系数
EE=0.5;%能量转换效率

Q_GCQ=5:5:100;
num=length(Q_GCQ);

Isn=zeros(1,num);
Ix=zeros(1,num);
Ix_GCQ=zeros(1,num);
Isy=zeros(1,num);
Isy_GCQ=zeros(1,num);

Isn2=zeros(1,num);
Ix2=zeros(1,num);
Ix_GCQ2=zeros(1,num);
Isy2=zeros(1,num);
Isy_GCQ2=zeros(1,num);

Isn3=zeros(1,num);
Ix3=zeros(1,num);
Ix_GCQ3=zeros(1,num);
Isy3=zeros(1,num);
Isy_GCQ3=zeros(1,num);

Isn4=zeros(1,num);
Ix4=zeros(1,num);
Ix_GCQ4=zeros(1,num);
Isy4=zeros(1,num);
Isy_GCQ4=zeros(1,num);


tau3=db2pow(-10);%灵敏度
tau4=db2pow(-15);%灵敏度

Period_X=20;

PsdB=5;  %dBm
SNRdB=5;
sigma_w=db2pow(PsdB-SNRdB);

PsdB2=15;  %dBm
SNRdB2=15;
sigma_w2=db2pow(PsdB2-SNRdB2);

tau=db2pow(-10);%灵敏度
tau2=db2pow(-15);%灵敏度

for index=1:num
[Isn(index),Ix(index), Ix_GCQ(index),Isy(index),Isy_GCQ(index)]=...
    FunctionECvsGCQitems(PsdB,sigma_w,eta,tau,EE,Q_GCQ(index),Period_X,sigma_sr0,sigma_st0,sigma_tr0,dist_sr,dist_st,dist_tr,alpha);  

[Isn2(index),Ix2(index), Ix_GCQ2(index),Isy2(index),Isy_GCQ2(index)]=...
    FunctionECvsGCQitems(PsdB,sigma_w,eta,tau2,EE,Q_GCQ(index),Period_X,sigma_sr0,sigma_st0,sigma_tr0,dist_sr,dist_st,dist_tr,alpha);  

[Isn3(index),Ix3(index), Ix_GCQ3(index),Isy3(index),Isy_GCQ3(index)]=...
    FunctionECvsGCQitems(PsdB2,sigma_w2,eta,tau3,EE,Q_GCQ(index),Period_X,sigma_sr0,sigma_st0,sigma_tr0,dist_sr,dist_st,dist_tr,alpha);  

[Isn4(index),Ix4(index), Ix_GCQ4(index),Isy4(index),Isy_GCQ4(index)]=...
    FunctionECvsGCQitems(PsdB2,sigma_w2,eta,tau4,EE,Q_GCQ(index),Period_X,sigma_sr0,sigma_st0,sigma_tr0,dist_sr,dist_st,dist_tr,alpha);  
end
%%
%close all;
figure;
subplot(2,1,1);
l1=plot(Q_GCQ,abs(Ix+Isy-Ix_GCQ-Isy_GCQ),'b-x','LineWidth',1); hold on;
l2=plot(Q_GCQ,abs(Ix2+Isy2-Ix_GCQ2-Isy_GCQ2),'r--','LineWidth',1); hold on;
l3=plot(Q_GCQ,abs(Ix3+Isy3-Ix_GCQ3-Isy_GCQ3),'k-o','LineWidth',1); hold on;
l4=plot(Q_GCQ,abs(Ix4+Isy4-Ix_GCQ4-Isy_GCQ4),'m:v','LineWidth',1); hold on;

xlabel('$m$','interpreter','latex')
ylabel('Absolute Error')
legend([l1,l2,l3,l4],'$\tau=-10\,$dBm, $\bar{\rho}=5\,$dB','$\tau=-15\,$dBm, $\bar{\rho}=5\,$dB','$\tau=-10\,$dBm, $\bar{\rho}=15\,$dB','$\tau=-15\,$dBm, $\bar{\rho}=15\,$dB','interpreter','latex')
grid on;

subplot(2,1,2);
l1=plot(Q_GCQ,abs(Ix+Isy-Ix_GCQ-Isy_GCQ)./(Isn+Ix+Isy),'b-x','LineWidth',1); hold on;
l2=plot(Q_GCQ,abs(Ix2+Isy2-Ix_GCQ2-Isy_GCQ2)./(Isn2+Ix2+Isy2),'r--','LineWidth',1); hold on;
l3=plot(Q_GCQ,abs(Ix3+Isy3-Ix_GCQ3-Isy_GCQ3)./(Isn3+Ix3+Isy3),'k-o','LineWidth',1); hold on;
l4=plot(Q_GCQ,abs(Ix4+Isy4-Ix_GCQ4-Isy_GCQ4)./(Isn4+Ix4+Isy4),'m:v','LineWidth',1); hold on;

xlabel('$m$','interpreter','latex')
ylabel('Relative Error')
legend([l1,l2,l3,l4],'$\tau=-10\,$dBm, $\bar{\rho}=5\,$dB','$\tau=-15\,$dBm, $\bar{\rho}=5\,$dB','$\tau=-10\,$dBm, $\bar{\rho}=15\,$dB','$\tau=-15\,$dBm, $\bar{\rho}=15\,$dB','interpreter','latex')
% legend([l1,l2,l3,l4],'$\tau=-10\,$dBm,$K=15$','$\tau=-15\,$dBm,$K=15$','$\tau=-10\,$dBm,$K=20$','$\tau=-15\,$dBm,$K=20$','interpreter','latex')
grid on;