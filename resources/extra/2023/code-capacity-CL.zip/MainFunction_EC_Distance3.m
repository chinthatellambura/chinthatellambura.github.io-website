clear; clc;
sigma_sr0=1; sigma_st0=1; sigma_tr0=1;

alpha=2;  %path loss
dist_sr=5;  %m
dist_st=0.5:0.5:6; %m

num=length(dist_st);

dist_tr=5*ones(1,num);  %m
% dist_st=0.5:0.5:4; %m
% dist_tr=sqrt(dist_sr^2+dist_st.^2-2*dist_sr.*dist_st*cos(pi/3));  %m
eta=0.3; %反射系数
EE=0.5;%能量转换效率


PsdB=15;  %dBm
SNRdB=15;
sigma_w=db2pow(PsdB-SNRdB);
%PsdB=50:5:90;

tau=db2pow(-15);%灵敏度
Ec=zeros(1,num);
Ec_GCQ=zeros(1,num);
Ec_lowSNR=zeros(1,num);
Ec_highSNR=zeros(1,num);
Ec_UB=zeros(1,num);
Ec_WO=zeros(1,num);
Ec_DR=zeros(1,num);
Ec_BR=zeros(1,num);

X_GCQ=100;
S_GCQ=100;
Period_X=20;

for index=1:num
    [Ec_WO(index), Ec_DR(index),Ec_BR(index),Ec(index),Ec_GCQ(index),Ec_lowSNR(index),Ec_highSNR(index),Ec_UB(index)]=...
    FunctionErgodicCapacitySensitivity3(PsdB,sigma_w,eta,tau,EE,X_GCQ,S_GCQ,Period_X,sigma_sr0,sigma_st0,sigma_tr0,dist_sr,dist_st(index),dist_tr(index),alpha);  
end

%%
%close all;
figure;
L1=plot(dist_st,Ec,'kx','LineWidth',1); hold on;
L2=plot(dist_st,Ec_GCQ,'b--','LineWidth',1); hold on;
% L3=plot(dist_st,Ec_lowSNR,'ro','LineWidth',1); hold on;
% L4=plot(dist_st,Ec_highSNR,'ms','LineWidth',1); hold on;
% L5=plot(dist_st,Ec_UB,'k:','LineWidth',1); hold on;
%L6=plot(dist_st,Ec_WO,'r-','LineWidth',1); hold on; %,'$\tilde{C}$'
L7=plot(dist_st,Ec_DR,'r-','LineWidth',1); hold on;
L8=plot(dist_st,Ec_BR,'m->','LineWidth',1); hold on;

alpha=3;  %path loss
for index=1:num
    [Ec_WO(index), Ec_DR(index),Ec_BR(index),Ec(index),Ec_GCQ(index),Ec_lowSNR(index),Ec_highSNR(index),Ec_UB(index)]=...
    FunctionErgodicCapacitySensitivity3(PsdB,sigma_w,eta,tau,EE,X_GCQ,S_GCQ,Period_X,sigma_sr0,sigma_st0,sigma_tr0,dist_sr,dist_st(index),dist_tr(index),alpha);  
end
 hold on;
plot(dist_st,Ec,'kx','LineWidth',1); hold on;
plot(dist_st,Ec_GCQ,'b--','LineWidth',1); hold on;
% plot(dist_st,Ec_lowSNR,'ro','LineWidth',1); hold on;
% plot(dist_st,Ec_highSNR,'ms','LineWidth',1); hold on;
% plot(dist_st,Ec_UB,'k:','LineWidth',1); hold on;
% plot(dist_st,Ec_WO,'r-','LineWidth',1); hold on; %,'$\tilde{C}$'
plot(dist_st,Ec_DR,'r-','LineWidth',1); hold on;
plot(dist_st,Ec_BR,'m->','LineWidth',1); hold on;

xlabel('Distance $d_{st}$\,(m)','interpreter','latex')
ylabel('Ergodic Capacity')
legend([L1,L2,L7,L8],'$\bar{C}$ (CABC)','$\bar{C}^{GCQ}$ (CABC)','$\hat{C}$ (Source-Reader)','$\check{C}$ (TABC)','interpreter','latex')
grid on;
 text(2,1,'$\alpha=2$','interpreter','latex','FontName','Times New Roman')
 text(3,1,'$\alpha=3$','interpreter','latex','FontName','Times New Roman')
 
 xlim([0.5 5.5])