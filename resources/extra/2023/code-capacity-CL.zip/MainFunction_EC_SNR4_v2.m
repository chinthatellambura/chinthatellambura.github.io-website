clear; clc;
sigma_sr0=1; sigma_st0=1; sigma_tr0=1;

alpha=2;     %path loss
alphaL=3;   %path loss
dist_sr=1;  %m
dist_st=1;  %m
dist_tr=1;  %m

eta=0.3; %反射系数
EE=0.5;%能量转换效率

%sigma_w(index)=1;
% PsdB=-10:5:30;

% sigma_w(index)=db2pow(0);
% PsdB=-10:5:30;
% %PsdB=50:5:90;
% num=length(PsdB);

sigma_w=1;
PsdB=-15:5:40;  %dBm
SNRdB=PsdB-pow2db(sigma_w);
%db2pow(PsdB-SNRdB);
num=length(PsdB);

% Pmax=240*10^(-6);   %240uw，最大输入功率
% v0=5*10^(-6);     %5uw
% v1=5000;
% v2=0.0002;
% Pc=8.9*10^(-6); %8.9uw,标签电路功耗  %标签电路功耗PC = 10 dBm
% logCoef=(Pmax*exp(v1*v0)+Pc*exp(v1*v2))/(Pmax-Pc); %自己推导正确的
% %logCoef=(Pmax*exp(v1*v2)+Pc*exp(v1*v0))/(Pmax-Pc)
% Phi=log(logCoef)/v1;
% tau=Phi;
tau=db2pow(-15);%灵敏度
Ec=zeros(1,num);
Ec_GCQ=zeros(1,num);
Ec_lowSNR=zeros(1,num);
Ec_highSNR=zeros(1,num);
Ec_UB=zeros(1,num);

Ec_WO=zeros(1,num);
Ec_WO_GCQ=zeros(1,num);
Ec_DR=zeros(1,num);
Ec_BR=zeros(1,num);

X_GCQ=100;
S_GCQ=100;
Period_X=20;

for index=1:num
[Ec_WO(index),Ec_WO_GCQ(index), Ec_DR(index),Ec_BR(index),Ec(index),Ec_GCQ(index),Ec_lowSNR(index),Ec_highSNR(index),Ec_UB(index)]=...
    FunctionErgodicCapacitySensitivity4(PsdB(index),sigma_w,eta,tau,EE,X_GCQ,S_GCQ,Period_X,sigma_sr0,sigma_st0,sigma_tr0,dist_sr,dist_st,dist_tr,alpha);  
end
sigma_st=sigma_st0/dist_st^alpha;
slope=(log2(10)+log2(10)./Period_X.*exp(-tau/EE/(1-eta)/db2pow(PsdB(num-1))/sigma_st))/10;
y=slope.*(SNRdB-SNRdB(num-1))+Ec(num-1);%10.468211354178349;%Ec_highSNR(num-3);
%y=slope.*((SNRdB)-(40))+Ec_highSNR(num);%10.468211354178349;%Ec_highSNR(num-3);
L0=tau/EE/(1-eta)./db2pow(PsdB);
sigma_sr=sigma_sr0/dist_sr^alpha;
sigma_tr=sigma_tr0/dist_tr^alpha;
coef=sigma_sr+(eta*sigma_st*sigma_tr).*gammainc(L0/sigma_st,2,'upper')*gamma(2);
Ec_lowSNR2=db2pow(SNRdB).*coef/log(2);
Ec_lowSNR3=db2pow(SNRdB).*sigma_sr/log(2);
%%
%close all;
figure;
%subplot(2,1,1);
L1=plot(SNRdB,Ec,'r','LineWidth',1); hold on;
L2=plot(SNRdB,Ec_GCQ,'bx','LineWidth',1); hold on;
L3=plot(SNRdB(1:6),Ec_lowSNR(1:6),'mo','LineWidth',1); hold on;
L32=plot(SNRdB(1:6),Ec_lowSNR2(1:6),'kp','LineWidth',1); hold on; 
%L33=plot(SNRdB(1:6),Ec_lowSNR3(1:6),'ms','LineWidth',1); hold on; 
L4=plot(SNRdB(5:12),Ec_highSNR(5:12),'rd','LineWidth',1); hold on;
L5=plot(SNRdB,Ec_UB,'k:','LineWidth',1); hold on;
%L6=plot(SNRdB(10:12),y(10:12),'c--','LineWidth',1); hold on;
L6=plot(SNRdB(3:12),y(3:12),'c--','LineWidth',1); hold on;
L7=plot(SNRdB,Ec_DR,'m-*','LineWidth',1); hold on;
L8=plot(SNRdB,Ec_BR,'b-+','LineWidth',1); hold on; %传统 AmBC

%L9=plot(SNRdB,Ec_WO,'g-.','LineWidth',1); hold on; %,'$\tilde{C}$' %无灵敏度约束 I_x+I_{s,y}
 text(5,10^(0),'$S=0.3488$','interpreter','latex','FontName','Times New Roman')
xlabel('SNR $\bar{\rho}$\,(dB)','interpreter','latex')
ylabel('Ergodic Capacity')
legend([L1,L2,L3,L32,L4,L5,L6,L7,L8],'$\bar{C}$ (CABC)','$\bar{C}^{GCQ}$ (CABC)','$\bar{C}^0$ (CABC, eq.(33))','$\bar{C}^0$ (CABC, eq.(34))',...
    '$\bar{C}^\infty$ (CABC)','$\bar{C}^{UB}$ (CABC)','$S$ (CABC)','$\hat{C}$ (Source--Reader)','$\check{C}$ (TABC)','interpreter','latex')
grid on;
xlim([-15,40])
ylim([0,16])

% subplot(2,1,2);
% L1=plot(SNRdB,Ec,'b:','LineWidth',1); hold on;
% %L2=plot(SNRdB,Ec_GCQ,'bx','LineWidth',1); hold on;
% L7=plot(SNRdB,Ec_DR,'ko','LineWidth',1); hold on; %端到端
% L8=plot(SNRdB,Ec_BR,'m->','LineWidth',1); hold on; %传统 AmBC
% %L9=plot(SNRdB,Ec_WO,'r-.','LineWidth',1); hold on; %,'$\tilde{C}$' %无灵敏度约束 I_x+I_{s,y}
% %L10=plot(SNRdB,Ec_WO_GCQ,'r+','LineWidth',1); hold on; %,'$\tilde{C}$' %无灵敏度约束 I_x+I_{s,y}
% xlabel('SNR $\bar{\rho}$\,(dB)','interpreter','latex')
% ylabel('Ergodic Capacity')
% legend([L1,L7,L8],'$\bar{C}$ (CABC)','$\hat{C}$ ($S$--$R$)','$\check{C}$ (TABC)','interpreter','latex')

%legend([L1,L7,L8,L9,L10],'$\bar{C}$ (CABC)','$\hat{C}$ ','$\check{C}$ (TABC)','$\tilde{C}$ (w/o sensitivity)','$\tilde{C}^{GCQ}$ (w/o sensitivity)','interpreter','latex')
%legend([L1,L2,L7,L8,L9,L10],'$\bar{C}$ (CABC)','$\bar{C}^{GCQ}$','$\hat{C}$','$\check{C}$','$\tilde{C}$','$\tilde{C}^{GCQ}$','interpreter','latex')
%legend([L1,L2,L3,L4,L5,L9,L8,L6,L7],'$\bar{C}$','$\bar{C}^{GCQ}$','$\bar{C}^0$','$\bar{C}^\infty$','$S$','$\bar{C}^{UB}$','$\hat{I}_{s,n}$','$I_x$','$\tilde{C}$','$\tilde{C}^{GCQ}$','interpreter','latex')