clear; clc;
sigma_sr0=1; sigma_st0=1; sigma_tr0=1;

alpha=2;     %path loss
alphaL=3;   %path loss
dist_sr=1;  %m
dist_st=1;  %m
dist_tr=1;  %m

eta=0.3; %反射系数
EE=0.5;%能量转换效率

%sigma_w(index)=1;
% PsdB=-10:5:30;

% sigma_w(index)=db2pow(0);
% PsdB=-10:5:30;
% %PsdB=50:5:90;
% num=length(PsdB);

sigma_w=1;
PsdB=15;  %dBm
%db2pow(PsdB-taudB);
taudB=-20:5:10;
tau=db2pow(taudB);%灵敏度
num=length(taudB);

% Pmax=240*10^(-6);   %240uw，最大输入功率
% v0=5*10^(-6);     %5uw
% v1=5000;
% v2=0.0002;
% Pc=8.9*10^(-6); %8.9uw,标签电路功耗  %标签电路功耗PC = 10 dBm
% logCoef=(Pmax*exp(v1*v0)+Pc*exp(v1*v2))/(Pmax-Pc); %自己推导正确的
% %logCoef=(Pmax*exp(v1*v2)+Pc*exp(v1*v0))/(Pmax-Pc)
% Phi=log(logCoef)/v1;
% tau=Phi;

Ec=zeros(1,num);
Ec_GCQ=zeros(1,num);
Ec_lowSNR=zeros(1,num);
Ec_highSNR=zeros(1,num);
Ec_UB=zeros(1,num);

Ec_WO=zeros(1,num);
Ec_WO_GCQ=zeros(1,num);
Ec_DR=zeros(1,num);
Ec_BR=zeros(1,num);

Ec2=zeros(1,num);
Ec_GCQ2=zeros(1,num);
Ec_lowSNR2=zeros(1,num);
Ec_highSNR2=zeros(1,num);
Ec_UB2=zeros(1,num);

Ec_WO2=zeros(1,num);
Ec_WO_GCQ2=zeros(1,num);
Ec_DR2=zeros(1,num);
Ec_BR2=zeros(1,num);

Ec3=zeros(1,num);
Ec_GCQ3=zeros(1,num);
Ec_lowSNR3=zeros(1,num);
Ec_highSNR3=zeros(1,num);
Ec_UB3=zeros(1,num);

Ec_WO3=zeros(1,num);
Ec_WO_GCQ3=zeros(1,num);
Ec_DR3=zeros(1,num);
Ec_BR3=zeros(1,num);

X_GCQ=100;
S_GCQ=100;

Period_X=10;
Period_X2=20;
Period_X3=30;
for index=1:num
[Ec_WO(index),Ec_WO_GCQ(index), Ec_DR(index),Ec_BR(index),Ec(index),Ec_GCQ(index),Ec_lowSNR(index),Ec_highSNR(index),Ec_UB(index)]=...
    FunctionErgodicCapacitySensitivity4(PsdB,sigma_w,eta,tau(index),EE,X_GCQ,S_GCQ,Period_X,sigma_sr0,sigma_st0,sigma_tr0,dist_sr,dist_st,dist_tr,alpha);  

[Ec_WO2(index),Ec_WO_GCQ2(index), Ec_DR2(index),Ec_BR2(index),Ec2(index),Ec_GCQ2(index),Ec_lowSNR2(index),Ec_highSNR2(index),Ec_UB2(index)]=...
    FunctionErgodicCapacitySensitivity4(PsdB,sigma_w,eta,tau(index),EE,X_GCQ,S_GCQ,Period_X2,sigma_sr0,sigma_st0,sigma_tr0,dist_sr,dist_st,dist_tr,alpha);  

[Ec_WO3(index),Ec_WO_GCQ3(index), Ec_DR3(index),Ec_BR3(index),Ec3(index),Ec_GCQ3(index),Ec_lowSNR3(index),Ec_highSNR3(index),Ec_UB3(index)]=...
    FunctionErgodicCapacitySensitivity4(PsdB,sigma_w,eta,tau(index),EE,X_GCQ,S_GCQ,Period_X3,sigma_sr0,sigma_st0,sigma_tr0,dist_sr,dist_st,dist_tr,alpha);  
 
end

%%
%close all;
figure;
subplot(2,1,1);
L1=plot(taudB,Ec,'bx','LineWidth',1); hold on;
L2=plot(taudB,Ec_GCQ,'r--','LineWidth',1); hold on;
L9=plot(taudB,Ec_DR,'k-.','LineWidth',1); hold on; %,'$\tilde{C}$' %无灵敏度约束 I_x+I_{s,y}

plot(taudB,Ec2,'bx','LineWidth',1); hold on;
plot(taudB,Ec_GCQ2,'r--','LineWidth',1); hold on;
plot(taudB,Ec_DR2,'k-.','LineWidth',1); hold on; %,'$\tilde{C}$' %无灵敏度约束 I_x+I_{s,y}

plot(taudB,Ec3,'bx','LineWidth',1); hold on;
plot(taudB,Ec_GCQ3,'r--','LineWidth',1); hold on;
plot(taudB,Ec_DR3,'k-.','LineWidth',1); hold on; %,'$\tilde{C}$' %无灵敏度约束 I_x+I_{s,y}

 text(-5,5,'$K=10$','interpreter','latex','FontName','Times New Roman')
 text(0,5,'$K=20$','interpreter','latex','FontName','Times New Roman')
 text(5,5,'$K=30$','interpreter','latex','FontName','Times New Roman')
 
legend([L1,L2,L9],'$\bar{C}$ (CABC)','$\bar{C}^{GCQ}$ (CABC)','$\hat{C}$ (Source--Reader)','interpreter','latex')
xlabel('Sensitivity $\tau$\,(dBm)','interpreter','latex')
ylabel('Ergodic Capacity')
grid on;

subplot(2,1,2);
L8=plot(taudB,Ec_BR,'m-o','LineWidth',1); hold on; %传统 AmBC
plot(taudB,Ec_BR2,'m-o','LineWidth',1); hold on; %传统 AmBC
plot(taudB,Ec_BR3,'m-o','LineWidth',1); hold on; %传统 AmBC
legend([L8],'$\check{C}$ (TABC)','interpreter','latex')
xlabel('Sensitivity $\tau$\,(dBm)','interpreter','latex')
ylabel('Ergodic Capacity')

 text(-5,0.3,'$K=10$','interpreter','latex','FontName','Times New Roman')
 text(0,0.3,'$K=20$','interpreter','latex','FontName','Times New Roman')
 text(5,0.3,'$K=30$','interpreter','latex','FontName','Times New Roman')
% subplot(2,1,2);
% L1=plot(taudB,Ec,'b:','LineWidth',1); hold on;
% %L2=plot(taudB,Ec_GCQ,'bx','LineWidth',1); hold on;
% L7=plot(taudB,Ec_DR,'ko','LineWidth',1); hold on; %端到端
% L8=plot(taudB,Ec_BR,'m->','LineWidth',1); hold on; %传统 AmBC
% %L9=plot(taudB,Ec_WO,'r-.','LineWidth',1); hold on; %,'$\tilde{C}$' %无灵敏度约束 I_x+I_{s,y}
% %L10=plot(taudB,Ec_WO_GCQ,'r+','LineWidth',1); hold on; %,'$\tilde{C}$' %无灵敏度约束 I_x+I_{s,y}
% xlabel('SNR $\bar{\rho}$\,(dB)','interpreter','latex')
% ylabel('Ergodic Capacity')
% legend([L1,L7,L8],'$\bar{C}$ (CABC)','$\hat{C}$ ($S$--$R$)','$\check{C}$ (TABC)','interpreter','latex')

%legend([L1,L7,L8,L9,L10],'$\bar{C}$ (CABC)','$\hat{C}$ ','$\check{C}$ (TABC)','$\tilde{C}$ (w/o sensitivity)','$\tilde{C}^{GCQ}$ (w/o sensitivity)','interpreter','latex')
%legend([L1,L2,L7,L8,L9,L10],'$\bar{C}$ (CABC)','$\bar{C}^{GCQ}$','$\hat{C}$','$\check{C}$','$\tilde{C}$','$\tilde{C}^{GCQ}$','interpreter','latex')
%legend([L1,L2,L3,L4,L5,L9,L8,L6,L7],'$\bar{C}$','$\bar{C}^{GCQ}$','$\bar{C}^0$','$\bar{C}^\infty$','$S$','$\bar{C}^{UB}$','$\hat{I}_{s,n}$','$I_x$','$\tilde{C}$','$\tilde{C}^{GCQ}$','interpreter','latex')